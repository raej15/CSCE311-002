# CSCE 350 Final Project Instructions

## Running All 75 Files
Navigate inside CSCE350Project_Jones_Sara folder \
run "make" in the terminal \
This will Generate both inputs and outputs (found in ./inputFiles and ./outputFiles respectively) \
Execution times will be appended to Jones_Sara_executionTime.txt

## Running One File
Navigate inside CSCE350Project_Jones_Sara folder \
Run 2 commands in the terminal: \
"g++ -o Jones_Sara_QuickSort Jones_Sara_QuickSort.cpp " \
"./Jones_Sara_QuickSort INPUT_FILE_PATH OUTPUT_FILE_PATH"

The sorted array will be put into the specified output file \
Execution times will be appended to Jones_Sara_executionTime.txt
